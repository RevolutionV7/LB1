﻿using System;

namespace LB1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!+1");
        }
    }
}
